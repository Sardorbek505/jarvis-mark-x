"""
Durable long-term memory for JARVIS — the foundation for being a real
secretary / friend / advisor that remembers you across restarts.

Storage backends (chosen automatically):
  • Postgres  — if env DATABASE_URL is set (e.g. free Neon DB). Survives
    Render restarts/redeploys → true long-term memory.
  • SQLite    — fallback. Works locally and on the PC, but on Render's free
    tier the file is wiped on restart (use DATABASE_URL for real persistence).
  • off       — last resort. Reads return nothing, writes are dropped.

Memory NEVER takes JARVIS down with it. If Postgres is unreachable (quota,
outage, bad URL) the store degrades to SQLite — or to `off` — logs loudly, and
`watch()` keeps re-trying Postgres in the background, promoting itself back the
moment the DB returns. A dead database costs memory, not the whole assistant.

Holds a per-user dossier (name / about / goals / preferences) and a list of
durable facts. Keeps an in-RAM cache so the system prompt can be built
synchronously while DB access stays async.
"""
import asyncio
import json
import logging
import os
from datetime import datetime
from pathlib import Path
from typing import Optional

logger = logging.getLogger("jarvis-memory")

_SQLITE_PATH = Path(__file__).resolve().parent.parent / "config" / "jarvis_memory.db"

# Сколько фактов доходит до модели. Раньше стояло «последние 60 штук», и при
# 88 накопленных 28 просто не попадали в контекст — причём самые СТАРЫЕ, то
# есть узнанные первыми: семья, кто человек, базовые предпочтения. Снаружи это
# и выглядит как «Джарвис тупой, он этого не знает».
#
# Считать штуками неправильно: важен объём. У Gemini контекст на миллион
# токенов, а 88 фактов — пара килобайт. Поэтому режем по символам и только
# когда их действительно много.
_FACTS_CHAR_BUDGET = 12000
_MAX_FACTS = 60  # оставлено для совместимости; отбор ниже идёт по объёму


# Каждое сообщение стоило ТРЁХ вызовов Gemini: ответ, извлечение фактов и
# эмбеддинг. Голосовое — пяти. На бесплатной квоте это прямой путь к 429, а
# платили мы её даже за «ок» и «спасибо». Вдобавок такие реплики попадали в
# семантическую память и засоряли поиск — то есть делали Джарвиса тупее.
#
# Список намеренно короткий: пропустить лишний факт не страшно, потерять
# настоящий — страшно. Поэтому отсекаем только явные поддакивания.
_ACKS = {
    "ок", "окей", "ok", "окей.", "ага", "угу", "да", "нет", "неа", "ясно",
    "понял", "понятно", "хорошо", "ладно", "спасибо", "спс", "благодарю",
    "привет", "здравствуй", "пока", "давай", "+", "👍", "❤️", "супер",
    "класс", "отлично", "принял", "готово", "ок спасибо", "хорошо спасибо",
}


def worth_learning(text: str) -> bool:
    """Стоит ли тратить на это вызовы модели (факты и эмбеддинг)."""
    t = (text or "").strip().lower().rstrip("!.,)?…")
    if not t or len(t) < 4:
        return False
    return t not in _ACKS


def _facts_for_context(facts: list) -> list:
    """Факты, влезающие в бюджет. Новые важнее старых только при переполнении."""
    out, used = [], 0
    for fact in reversed(facts):                 # с конца — новые приоритетнее
        cost = len(fact) + 2                     # «; » между фактами
        if used + cost > _FACTS_CHAR_BUDGET and out:
            break
        out.append(fact)
        used += cost
    out.reverse()                                # вернуть хронологический порядок
    return out

_PG_RETRY_SEC = 300     # how often a degraded store re-tries Postgres
# A permanently-open pool connection keeps a serverless Postgres (Neon) awake
# 24/7 and eats the whole free compute quota in ~8 days. Idle connections must
# die so the DB can auto-suspend.
_PG_IDLE_CLOSE_SEC = 60.0
_PG_MAX_SIZE = 3
# A suspended serverless DB does not refuse connections — it accepts and never
# answers. Without a hard cap the app hangs in startup forever, which on a
# health-checked platform is worse than crashing. Degrade fast instead.
_PG_CONNECT_TIMEOUT = 10.0   # per TCP/auth attempt
_PG_INIT_TIMEOUT = 25.0      # whole connect + schema step

# Every table keyed by a `user_id` column. SINGLE SOURCE for clear()/GDPR wipe —
# when you add a new per-user table, add it here so /forget can never leave data
# behind (this list prevents the clear()-drift bug class). `habit_checks` is keyed
# by habit_id, not user_id, so it is wiped separately in clear().
USER_TABLES = (
    "facts", "profile", "tasks", "habits", "reminders",
    "notes", "schedule", "projects", "outbox", "contacts", "meta", "messages",
    "embeddings", "journal", "mood", "expenses",
)


class MemoryStore:
    def __init__(self):
        self._url = os.getenv("DATABASE_URL", "").strip()
        self._wants_pg = self._url.startswith(("postgres://", "postgresql://"))
        self._backend = "off"      # "pg" | "sqlite" | "off"
        self._pool = None          # asyncpg pool
        self._sqlite = None        # aiosqlite connection
        self._cache: dict = {}     # uid -> {"profile": {...}, "facts": [str]}
        self.degraded_reason = ""  # why Postgres is unavailable (for /memstats)

    @property
    def _pg(self) -> bool:
        return self._backend == "pg"

    @property
    def degraded(self) -> bool:
        """Postgres was configured but we are running on a fallback backend."""
        return self._wants_pg and self._backend != "pg"

    # ── lifecycle ──────────────────────────────────────────────────────────────

    async def init(self):
        """Bring up the best available backend. Never raises — a broken database
        must not stop JARVIS from starting."""
        if self._wants_pg:
            try:
                await asyncio.wait_for(self._connect_pg(), _PG_INIT_TIMEOUT)
                return
            except Exception as e:
                self.degraded_reason = _first_line(e)
                logger.critical(
                    "Memory: Postgres НЕДОСТУПЕН (%s). Джарвис стартует на временной "
                    "SQLite-памяти; записи этого периода в основную базу не попадут. "
                    "Повторяю попытку каждые %d с.",
                    self.degraded_reason, _PG_RETRY_SEC,
                )
        try:
            await self._connect_sqlite()
        except Exception as e:
            self._backend = "off"
            logger.critical(
                "Memory: SQLite тоже недоступен (%s) — работаю БЕЗ памяти.", _first_line(e)
            )

    async def _connect_pg(self):
        import asyncpg
        pool = await asyncpg.create_pool(
            self._url,
            min_size=0,                      # см. _PG_IDLE_CLOSE_SEC
            max_size=_PG_MAX_SIZE,
            max_inactive_connection_lifetime=_PG_IDLE_CLOSE_SEC,
            timeout=_PG_CONNECT_TIMEOUT,
            **_pg_pool_kwargs(self._url),
        )
        self._pool = pool
        try:
            await self._exec_pg(_SCHEMA_PG)
            await self._exec_pg("ALTER TABLE profile ADD COLUMN IF NOT EXISTS mode TEXT DEFAULT ''")
            await self._exec_pg("ALTER TABLE contacts ADD COLUMN IF NOT EXISTS note TEXT DEFAULT ''")
        except Exception:
            self._pool = None
            await pool.close()
            raise
        self._backend = "pg"
        self.degraded_reason = ""
        logger.info("Memory: Postgres connected (durable) ✅")

    async def _connect_sqlite(self):
        import aiosqlite
        _SQLITE_PATH.parent.mkdir(parents=True, exist_ok=True)
        self._sqlite = await aiosqlite.connect(_SQLITE_PATH)
        await self._sqlite.execute("PRAGMA journal_mode = WAL;")
        await self._sqlite.execute("PRAGMA synchronous = NORMAL;")
        await self._sqlite.executescript(_SCHEMA_SQLITE)
        # Досыпаем колонки, которых нет. Раньше ALTER выполнялся вслепую и на
        # уже мигрированной базе падал ожидаемым "duplicate column name" —
        # который логировался с полным трейсбеком. Такой шум при КАЖДОМ запуске
        # фолбэка и прячет настоящие ошибки, ради которых лог и читают.
        for table, column, ddl in (
            ("profile", "mode", "ALTER TABLE profile ADD COLUMN mode TEXT DEFAULT ''"),
            ("contacts", "note", "ALTER TABLE contacts ADD COLUMN note TEXT DEFAULT ''"),
        ):
            try:
                cur = await self._sqlite.execute(f"PRAGMA table_info({table})")
                have = {row[1] for row in await cur.fetchall()}
                if column not in have:
                    await self._sqlite.execute(ddl)
            except Exception as exc:
                logger.warning("Миграция %s.%s не прошла: %s", table, column, exc)
        await self._sqlite.commit()
        self._backend = "sqlite"
        logger.warning(
            "Memory: SQLite fallback (ephemeral on Render free). "
            "Set DATABASE_URL to a free Postgres for permanent memory."
        )

    async def watch(self):
        """Background self-healing: while degraded, keep dialling Postgres and
        promote back to it the moment it answers. Run as a task; cancel-safe."""
        while True:
            await asyncio.sleep(_PG_RETRY_SEC)
            if not self.degraded:
                continue
            try:
                await asyncio.wait_for(self._connect_pg(), _PG_INIT_TIMEOUT)
            except Exception as e:
                reason = _first_line(e)
                if reason != self.degraded_reason:   # only log when it changes
                    self.degraded_reason = reason
                    logger.warning("Memory: Postgres всё ещё недоступен (%s)", reason)
                continue
            # Promoted. The SQLite handle stays open on purpose: in-flight calls
            # that already picked it must not blow up mid-query.
            self._cache.clear()
            # Векторы тоже: они прочитаны из ВРЕМЕННОГО хранилища, и после
            # возврата на основную базу всплывали бы в поиске как настоящие.
            from telegram_bot import memory_rag
            memory_rag._VECS.clear()
            logger.warning(
                "Memory: Postgres вернулся — снова на постоянной памяти ✅. "
                "Данные, записанные во время сбоя, остались в %s.", _SQLITE_PATH.name,
            )

    async def close(self):
        if self._pool:
            await self._pool.close()
        if self._sqlite:
            await self._sqlite.close()
        self._backend = "off"

    # ── low-level helpers ──────────────────────────────────────────────────────

    async def _exec_pg(self, sql: str, *args):
        async with self._pool.acquire() as con:
            return await con.execute(sql, *args)

    async def _exec(self, sql: str, args: tuple = ()):
        if self._backend == "off":
            return
        if self._pg:
            async with self._pool.acquire() as con:
                await con.execute(_pg(sql), *args)
        else:
            await self._sqlite.execute(sql, args)
            await self._sqlite.commit()

    async def _fetchone(self, sql: str, args: tuple = ()):
        if self._backend == "off":
            return None
        if self._pg:
            async with self._pool.acquire() as con:
                row = await con.fetchrow(_pg(sql), *args)
                return tuple(row) if row else None
        async with self._sqlite.execute(sql, args) as cur:
            return await cur.fetchone()

    async def _fetchall(self, sql: str, args: tuple = ()):
        if self._backend == "off":
            return []
        if self._pg:
            async with self._pool.acquire() as con:
                rows = await con.fetch(_pg(sql), *args)
                return [tuple(r) for r in rows]
        async with self._sqlite.execute(sql, args) as cur:
            return await cur.fetchall()

    # ── cache ──────────────────────────────────────────────────────────────────

    async def ensure_loaded(self, uid: int):
        """Load this user's dossier + facts + open tasks into the RAM cache (once)."""
        if uid in self._cache:
            return
        # Семь независимых запросов — параллельно, а не в очередь. Последовательно
        # это семь round-trip до Neon подряд, и всё это на ПЕРВОМ сообщении после
        # каждого рестарта: заметная пауза там, где человек ждёт ответа.
        profile, facts, tasks, contacts, schedule, projects, notes = await asyncio.gather(
            self._load_profile(uid),
            self._load_facts(uid),
            self._load_tasks(uid),
            self.list_contacts(uid),
            self.list_schedule(uid),
            self.list_projects(uid),
            self.list_notes(uid, limit=12),
        )
        self._cache[uid] = {
            "profile": profile, "facts": facts, "tasks": tasks,
            "contacts": contacts,
            "schedule": schedule,
            "projects": projects,
            "notes": notes,
        }

    def cached_notes(self, uid: int) -> list:
        """Recent notes from cache (for the system prompt → JARVIS can recall them)."""
        d = self._cache.get(uid)
        return d.get("notes", []) if d else []

    def cached_facts(self, uid: int) -> list:
        """Durable facts from cache (used by in-chat recall search)."""
        d = self._cache.get(uid)
        return d.get("facts", []) if d else []

    async def _refresh_notes_cache(self, uid: int):
        if uid in self._cache:
            self._cache[uid]["notes"] = await self.list_notes(uid, limit=12)

    async def search_notes(self, uid: int, query: str) -> list:
        q = f"%{query.strip().lower()}%"
        rows = await self._fetchall(
            "SELECT id, text, created_at FROM notes WHERE user_id=? AND lower(text) LIKE ? "
            "ORDER BY id DESC LIMIT 20",
            (uid, q),
        )
        return [{"id": r[0], "text": r[1], "created_at": r[2]} for r in rows]

    def cached_contacts(self, uid: int) -> list:
        """Whitelisted contact aliases from cache (for the system prompt)."""
        d = self._cache.get(uid)
        return d.get("contacts", []) if d else []

    def cached_schedule(self, uid: int) -> list:
        """Full weekly schedule from cache (for the system prompt)."""
        d = self._cache.get(uid)
        return d.get("schedule", []) if d else []

    async def _refresh_schedule_cache(self, uid: int):
        if uid in self._cache:
            self._cache[uid]["schedule"] = await self.list_schedule(uid)

    def cached_block(self, uid: int) -> str:
        """Synchronous context string for the system prompt (from RAM cache)."""
        data = self._cache.get(uid)
        if not data:
            return ""
        p = data["profile"]
        facts = data["facts"]
        parts: list[str] = []
        if p.get("name"):
            parts.append(f"Имя пользователя: {p['name']}.")
        if p.get("about"):
            parts.append(f"О пользователе: {p['about']}")
        if p.get("goals"):
            parts.append(f"Его цели: {p['goals']}")
        if p.get("preferences"):
            parts.append(f"Предпочтения: {p['preferences']}")
        if facts:
            joined = "; ".join(_facts_for_context(facts))
            parts.append(f"Что я о нём помню: {joined}")
        tasks = data.get("tasks", [])
        if tasks:
            tlines = []
            for t in tasks[:15]:
                due = t.get("due")
                when = ""
                if due:
                    try:
                        d = datetime.fromisoformat(due)
                        when = (" — " + d.strftime("%d.%m %H:%M")) if (d.hour or d.minute) \
                            else (" — " + d.strftime("%d.%m"))
                    except Exception as exc:
                        logger.warning("Подавлено исключение: %s", exc, exc_info=True)
                tlines.append(f"{t['title']}{when}")
            parts.append("Его актуальные задачи/планы: " + "; ".join(tlines))
        if not parts:
            return ""
        return "ПАМЯТЬ О ПОЛЬЗОВАТЕЛЕ (используй это, помни как близкий человек): " + " ".join(parts)

    def cached_mode(self, uid: int) -> str:
        """Synchronous personality-mode id from cache (for the system prompt)."""
        data = self._cache.get(uid)
        return (data["profile"].get("mode") or "") if data else ""

    async def get_mode(self, uid: int) -> str:
        await self.ensure_loaded(uid)
        return self._cache[uid]["profile"].get("mode", "")

    async def set_mode(self, uid: int, mode: str):
        await self.set_profile_field(uid, "mode", mode)

    # ── profile ────────────────────────────────────────────────────────────────

    async def _load_profile(self, uid: int) -> dict:
        row = await self._fetchone(
            "SELECT name, about, goals, preferences, mode FROM profile WHERE user_id=?", (uid,)
        )
        if not row:
            return {}
        return {"name": row[0] or "", "about": row[1] or "",
                "goals": row[2] or "", "preferences": row[3] or "",
                "mode": row[4] or ""}

    async def get_profile(self, uid: int) -> dict:
        await self.ensure_loaded(uid)
        return dict(self._cache[uid]["profile"])

    async def set_profile_field(self, uid: int, field: str, value: str):
        if field not in ("name", "about", "goals", "preferences", "mode"):
            return
        await self.ensure_loaded(uid)
        now = datetime.now().isoformat()
        cur = self._cache[uid]["profile"]
        vals = {f: (value if f == field else cur.get(f, "")) for f in _PROFILE_FIELDS}
        # Upsert all known fields; only `field` actually changes
        await self._exec(
            "INSERT INTO profile(user_id, name, about, goals, preferences, mode, updated_at) "
            "VALUES(?,?,?,?,?,?,?) "
            "ON CONFLICT(user_id) DO UPDATE SET "
            f"{field}=excluded.{field}, updated_at=excluded.updated_at",
            (uid, vals["name"], vals["about"], vals["goals"],
             vals["preferences"], vals["mode"], now),
        )
        cur[field] = value

    # ── facts ──────────────────────────────────────────────────────────────────

    async def _load_facts(self, uid: int) -> list:
        rows = await self._fetchall(
            "SELECT fact FROM facts WHERE user_id=? ORDER BY id ASC", (uid,)
        )
        return [r[0] for r in rows]

    async def add_fact(self, uid: int, fact: str) -> bool:
        fact = (fact or "").strip()
        if not fact:
            return False
        await self.ensure_loaded(uid)
        existing = self._cache[uid]["facts"]
        # Skip near-duplicates (case-insensitive substring either way)
        low = fact.lower()
        for f in existing:
            fl = f.lower()
            if low == fl or low in fl or fl in low:
                return False
        await self._exec(
            "INSERT INTO facts(user_id, fact, ts) VALUES(?,?,?)",
            (uid, fact, datetime.now().isoformat()),
        )
        existing.append(fact)
        return True

    async def get_facts(self, uid: int) -> list:
        await self.ensure_loaded(uid)
        return list(self._cache[uid]["facts"])

    async def del_fact(self, uid: int, index: int) -> str:
        """Удалить ОДИН факт по его номеру в get_facts (с 1). Возвращает текст
        удалённого или "" — если номера нет.

        Досье пополняется автоматически, и ошибочный факт туда попасть может.
        До этого единственным способом убрать один неверный факт было стереть
        всю память целиком — за компанию с сотней верных.
        """
        facts = await self.get_facts(uid)
        if not 1 <= index <= len(facts):
            return ""
        fact = facts[index - 1]
        await self._exec("DELETE FROM facts WHERE user_id=? AND fact=?", (uid, fact))
        # Текст факта лежит ещё и в эмбеддингах. Без этой строки удалённое
        # вернулось бы обратно — через поиск по смыслу, прямо в промпт.
        await self._exec("DELETE FROM embeddings WHERE user_id=? AND text=?", (uid, fact))
        self._cache[uid]["facts"] = [f for f in self._cache[uid]["facts"] if f != fact]
        from telegram_bot import memory_rag
        memory_rag.forget_cached(uid)
        return fact

    # ── tasks / calendar ─────────────────────────────────────────────────────────

    async def _load_tasks(self, uid: int) -> list:
        rows = await self._fetchall(
            "SELECT id, title, due, done FROM tasks WHERE user_id=? AND done=0", (uid,)
        )
        items = [{"id": r[0], "title": r[1], "due": r[2]} for r in rows]
        return _sort_tasks(items)

    async def add_task(self, uid: int, title: str, due: Optional[str] = None) -> dict:
        title = (title or "").strip()
        await self.ensure_loaded(uid)
        await self._exec(
            "INSERT INTO tasks(user_id, title, due, done, created_at) VALUES(?,?,?,0,?)",
            (uid, title, due, datetime.now().isoformat()),
        )
        row = await self._fetchone(
            "SELECT id FROM tasks WHERE user_id=? ORDER BY id DESC LIMIT 1", (uid,)
        )
        task = {"id": row[0] if row else 0, "title": title, "due": due}
        self._cache[uid]["tasks"] = _sort_tasks(self._cache[uid]["tasks"] + [task])
        return task

    async def get_tasks(self, uid: int) -> list:
        await self.ensure_loaded(uid)
        return list(self._cache[uid]["tasks"])

    async def complete_task(self, uid: int, task_id: int) -> Optional[dict]:
        await self.ensure_loaded(uid)
        match = next((t for t in self._cache[uid]["tasks"] if t["id"] == task_id), None)
        if not match:
            return None
        await self._exec("UPDATE tasks SET done=1 WHERE id=? AND user_id=?", (task_id, uid))
        self._cache[uid]["tasks"] = [t for t in self._cache[uid]["tasks"] if t["id"] != task_id]
        return match

    async def delete_task(self, uid: int, task_id: int) -> bool:
        await self.ensure_loaded(uid)
        owner = await self._fetchone(
            "SELECT 1 FROM tasks WHERE id=? AND user_id=?", (task_id, uid)
        )
        if not owner:
            return False
        await self._exec("DELETE FROM tasks WHERE id=? AND user_id=?", (task_id, uid))
        self._cache[uid]["tasks"] = [t for t in self._cache[uid]["tasks"] if t["id"] != task_id]
        return True

    # ── habits ───────────────────────────────────────────────────────────────────

    async def add_habit(self, uid: int, title: str) -> dict:
        title = (title or "").strip()
        await self._exec(
            "INSERT INTO habits(user_id, title, created_at) VALUES(?,?,?)",
            (uid, title, datetime.now().isoformat()),
        )
        row = await self._fetchone(
            "SELECT id FROM habits WHERE user_id=? ORDER BY id DESC LIMIT 1", (uid,)
        )
        return {"id": row[0] if row else 0, "title": title}

    async def _habit_days(self, habit_id: int) -> set:
        rows = await self._fetchall(
            "SELECT day FROM habit_checks WHERE habit_id=?", (habit_id,)
        )
        return {r[0] for r in rows}

    async def get_habits(self, uid: int, today: str) -> list:
        rows = await self._fetchall(
            "SELECT id, title FROM habits WHERE user_id=? ORDER BY id ASC", (uid,)
        )
        out = []
        for hid, title in rows:
            days = await self._habit_days(hid)
            out.append({
                "id": hid, "title": title,
                "done_today": today in days,
                "streak": _streak(days, today),
            })
        return out

    async def toggle_habit(self, uid: int, habit_id: int, day: str) -> Optional[bool]:
        owner = await self._fetchone(
            "SELECT id FROM habits WHERE id=? AND user_id=?", (habit_id, uid)
        )
        if not owner:
            return None
        exists = await self._fetchone(
            "SELECT 1 FROM habit_checks WHERE habit_id=? AND day=?", (habit_id, day)
        )
        if exists:
            await self._exec(
                "DELETE FROM habit_checks WHERE habit_id=? AND day=?", (habit_id, day)
            )
            return False
        await self._exec(
            "INSERT INTO habit_checks(habit_id, day) VALUES(?,?)", (habit_id, day)
        )
        return True

    async def delete_habit(self, uid: int, habit_id: int) -> bool:
        owner = await self._fetchone(
            "SELECT id FROM habits WHERE id=? AND user_id=?", (habit_id, uid)
        )
        if not owner:
            return False
        await self._exec("DELETE FROM habit_checks WHERE habit_id=?", (habit_id,))
        await self._exec("DELETE FROM habits WHERE id=? AND user_id=?", (habit_id, uid))
        return True

    # ── reminders (durable, timezone-correct: due stored as UTC ISO) ─────────────

    async def add_reminder(self, uid: int, text: str, due_utc_iso: str) -> dict:
        await self._exec(
            "INSERT INTO reminders(user_id, text, due, sent, created_at) VALUES(?,?,?,0,?)",
            (uid, (text or "").strip(), due_utc_iso, datetime.now().isoformat()),
        )
        row = await self._fetchone(
            "SELECT id FROM reminders WHERE user_id=? ORDER BY id DESC LIMIT 1", (uid,)
        )
        return {"id": row[0] if row else 0, "text": text, "due": due_utc_iso}

    async def get_due_reminders(self, now_utc_iso: str) -> list:
        rows = await self._fetchall(
            "SELECT id, user_id, text, due FROM reminders WHERE sent=0", ()
        )
        return [
            {"id": r[0], "user_id": r[1], "text": r[2], "due": r[3]}
            for r in rows if r[3] and r[3] <= now_utc_iso
        ]

    async def mark_reminder_sent(self, reminder_id: int):
        await self._exec("UPDATE reminders SET sent=1 WHERE id=?", (reminder_id,))

    async def delete_reminder(self, uid: int, reminder_id: int) -> bool:
        owner = await self._fetchone(
            "SELECT 1 FROM reminders WHERE id=? AND user_id=?", (reminder_id, uid)
        )
        if not owner:
            return False
        await self._exec("DELETE FROM reminders WHERE id=? AND user_id=?", (reminder_id, uid))
        return True

    async def list_reminders(self, uid: int) -> list:
        rows = await self._fetchall(
            "SELECT id, text, due FROM reminders WHERE user_id=? AND sent=0 ORDER BY due ASC",
            (uid,),
        )
        return [{"id": r[0], "text": r[1], "due": r[2]} for r in rows]

    # ── meta (proactive bookkeeping) + recipients ────────────────────────────────

    async def set_meta(self, uid: int, key: str, value: str):
        await self._exec(
            "INSERT INTO meta(user_id, key, value) VALUES(?,?,?) "
            "ON CONFLICT(user_id, key) DO UPDATE SET value=excluded.value",
            (uid, key, value),
        )

    async def get_meta(self, uid: int, key: str) -> Optional[str]:
        row = await self._fetchone(
            "SELECT value FROM meta WHERE user_id=? AND key=?", (uid, key)
        )
        return row[0] if row else None

    # ── contacts whitelist (JARVIS Outbound) ─────────────────────────────────────

    async def add_contact(self, uid: int, alias: str, target: str, note: str = ""):
        await self._exec(
            "INSERT INTO contacts(user_id, alias, target, note, created_at) VALUES(?,?,?,?,?) "
            "ON CONFLICT(user_id, alias) DO UPDATE SET target=excluded.target, note=excluded.note",
            (uid, alias.strip().lower(), target.strip(), (note or "").strip(),
             datetime.now().isoformat(timespec="seconds")),
        )
        await self._refresh_contacts_cache(uid)

    async def _refresh_contacts_cache(self, uid: int):
        if uid in self._cache:
            self._cache[uid]["contacts"] = await self.list_contacts(uid)

    async def list_contacts(self, uid: int) -> list:
        rows = await self._fetchall(
            "SELECT alias, target, note FROM contacts WHERE user_id=? ORDER BY alias", (uid,)
        )
        return [{"alias": r[0], "target": r[1], "note": r[2] or ""} for r in rows]

    async def del_contact(self, uid: int, alias: str) -> bool:
        a = alias.strip().lower()
        existed = await self._fetchone(
            "SELECT 1 FROM contacts WHERE user_id=? AND alias=?", (uid, a)
        )
        if not existed:
            return False
        await self._exec("DELETE FROM contacts WHERE user_id=? AND alias=?", (uid, a))
        await self._refresh_contacts_cache(uid)
        return True

    async def resolve_contact(self, uid: int, name: str) -> Optional[str]:
        """Map a spoken/typed name to a whitelisted target (@username/phone/id).
        Exact alias match first, then a forgiving partial match."""
        n = (name or "").strip().lower()
        if not n:
            return None
        rows = await self._fetchall(
            "SELECT alias, target FROM contacts WHERE user_id=?", (uid,)
        )
        for alias, target in rows:
            if alias == n:
                return target
        for alias, target in rows:
            if n in alias or alias in n:
                return target
        return None

    # ── outbox (очередь Outbound: отправить, когда ПК онлайн) ────────────────────

    async def queue_outbound(self, uid: int, target: str, alias: str, message: str, as_voice: bool):
        await self._exec(
            "INSERT INTO outbox(user_id, target, alias, message, as_voice, created_at) "
            "VALUES(?,?,?,?,?,?)",
            (uid, target, alias, message, 1 if as_voice else 0,
             datetime.now().isoformat(timespec="seconds")),
        )

    async def pending_outbound(self, uid: Optional[int] = None) -> list:
        if uid is None:
            rows = await self._fetchall(
                "SELECT id, user_id, target, alias, message, as_voice FROM outbox ORDER BY id", ()
            )
        else:
            rows = await self._fetchall(
                "SELECT id, user_id, target, alias, message, as_voice FROM outbox WHERE user_id=? ORDER BY id",
                (uid,),
            )
        return [{"id": r[0], "user_id": r[1], "target": r[2], "alias": r[3],
                 "message": r[4], "as_voice": bool(r[5])} for r in rows]

    async def delete_outbound(self, item_id: int):
        await self._exec("DELETE FROM outbox WHERE id=?", (item_id,))

    # ── notes (единая входящая: свободные мысли/идеи) ────────────────────────────

    async def add_note(self, uid: int, text: str) -> dict:
        text = text.strip()
        await self._exec(
            "INSERT INTO notes(user_id, text, created_at) VALUES(?,?,?)",
            (uid, text, datetime.now().isoformat(timespec="seconds")),
        )
        row = await self._fetchone(
            "SELECT id FROM notes WHERE user_id=? ORDER BY id DESC LIMIT 1", (uid,)
        )
        await self._refresh_notes_cache(uid)
        return {"id": row[0] if row else None, "text": text}

    async def list_notes(self, uid: int, limit: int = 50) -> list:
        rows = await self._fetchall(
            "SELECT id, text, created_at FROM notes WHERE user_id=? ORDER BY id DESC LIMIT ?",
            (uid, limit),
        )
        return [{"id": r[0], "text": r[1], "created_at": r[2]} for r in rows]

    async def delete_note(self, uid: int, note_id: int) -> bool:
        owner = await self._fetchone(
            "SELECT 1 FROM notes WHERE id=? AND user_id=?", (note_id, uid)
        )
        if not owner:
            return False
        await self._exec("DELETE FROM notes WHERE id=? AND user_id=?", (note_id, uid))
        await self._refresh_notes_cache(uid)
        return True

    # ── schedule (расписание пар) ────────────────────────────────────────────────

    async def add_class(self, uid: int, weekday: int, time: str, subject: str, location: str = "") -> dict:
        await self._exec(
            "INSERT INTO schedule(user_id, weekday, time, subject, location, created_at) "
            "VALUES(?,?,?,?,?,?)",
            (uid, int(weekday), (time or "").strip(), subject.strip(), (location or "").strip(),
             datetime.now().isoformat(timespec="seconds")),
        )
        row = await self._fetchone(
            "SELECT id FROM schedule WHERE user_id=? ORDER BY id DESC LIMIT 1", (uid,)
        )
        await self._refresh_schedule_cache(uid)
        return {"id": row[0] if row else None}

    async def list_schedule(self, uid: int) -> list:
        rows = await self._fetchall(
            "SELECT id, weekday, time, subject, location FROM schedule WHERE user_id=? "
            "ORDER BY weekday, time", (uid,)
        )
        return [{"id": r[0], "weekday": r[1], "time": r[2], "subject": r[3], "location": r[4]} for r in rows]

    async def schedule_for_day(self, uid: int, weekday: int) -> list:
        rows = await self._fetchall(
            "SELECT id, weekday, time, subject, location FROM schedule WHERE user_id=? AND weekday=? "
            "ORDER BY time", (uid, int(weekday))
        )
        return [{"id": r[0], "weekday": r[1], "time": r[2], "subject": r[3], "location": r[4]} for r in rows]

    async def delete_class(self, uid: int, class_id: int) -> bool:
        owner = await self._fetchone(
            "SELECT 1 FROM schedule WHERE id=? AND user_id=?", (class_id, uid)
        )
        if not owner:
            return False
        await self._exec("DELETE FROM schedule WHERE id=? AND user_id=?", (class_id, uid))
        await self._refresh_schedule_cache(uid)
        return True

    async def clear_schedule(self, uid: int):
        await self._exec("DELETE FROM schedule WHERE user_id=?", (uid,))
        await self._refresh_schedule_cache(uid)

    # ── projects (трекер статусов проектов) ──────────────────────────────────────

    async def upsert_project(self, uid: int, name: str, status: str) -> dict:
        name = name.strip()
        await self._exec(
            "INSERT INTO projects(user_id, name, status, updated_at) VALUES(?,?,?,?) "
            "ON CONFLICT(user_id, name) DO UPDATE SET status=excluded.status, updated_at=excluded.updated_at",
            (uid, name, status.strip(), datetime.now().isoformat(timespec="seconds")),
        )
        await self._refresh_projects_cache(uid)
        return {"name": name, "status": status.strip()}

    async def list_projects(self, uid: int) -> list:
        rows = await self._fetchall(
            "SELECT name, status, updated_at FROM projects WHERE user_id=? ORDER BY updated_at DESC",
            (uid,),
        )
        return [{"name": r[0], "status": r[1], "updated_at": r[2]} for r in rows]

    async def delete_project(self, uid: int, name: str) -> bool:
        n = name.strip()
        owner = await self._fetchone(
            "SELECT 1 FROM projects WHERE user_id=? AND lower(name)=lower(?)", (uid, n)
        )
        if not owner:
            return False
        await self._exec("DELETE FROM projects WHERE user_id=? AND lower(name)=lower(?)", (uid, n))
        await self._refresh_projects_cache(uid)
        return True

    def cached_projects(self, uid: int) -> list:
        d = self._cache.get(uid)
        return d.get("projects", []) if d else []

    async def _refresh_projects_cache(self, uid: int):
        if uid in self._cache:
            self._cache[uid]["projects"] = await self.list_projects(uid)

    async def all_user_ids(self) -> list:
        """Every user the bot knows — to deliver proactive briefings to."""
        rows = await self._fetchall(
            "SELECT user_id FROM profile "
            "UNION SELECT user_id FROM tasks "
            "UNION SELECT user_id FROM facts "
            "UNION SELECT user_id FROM meta"
        )
        return [r[0] for r in rows]

    async def clear(self, uid: int):
        rows = await self._fetchall("SELECT id FROM habits WHERE user_id=?", (uid,))
        for (hid,) in rows:
            await self._exec("DELETE FROM habit_checks WHERE habit_id=?", (hid,))
        for tbl in USER_TABLES:
            await self._exec(f"DELETE FROM {tbl} WHERE user_id=?", (uid,))
        self._cache.pop(uid, None)
        # Иначе стёртые воспоминания продолжат всплывать в семантическом поиске
        # из РАМ-кэша векторов — /forget должен забывать по-настоящему.
        from telegram_bot import memory_rag
        memory_rag.forget_cached(uid)

    # ── conversation log (every message, durable) ───────────────────────────────

    async def add_message(self, uid: int, role: str, text: str):
        """Persist one chat message forever (role = 'user' | 'model'). This is the
        raw log that survives restarts — foundation for full recall / RAG."""
        text = (text or "").strip()
        if not text:
            return
        await self._exec(
            "INSERT INTO messages(user_id, role, text, created_at) VALUES(?,?,?,?)",
            (uid, role, text, datetime.now().isoformat()),
        )

    async def recent_messages(self, uid: int, limit: int = 40) -> list:
        """Last N messages (oldest→newest) to re-seed the chat window after a
        restart. Returns [{'role','text'}]."""
        rows = await self._fetchall(
            "SELECT role, text FROM (SELECT id, role, text FROM messages "
            "WHERE user_id=? ORDER BY id DESC LIMIT ?) sub ORDER BY id ASC",
            (uid, limit),
        )
        return [{"role": r[0], "text": r[1]} for r in rows]

    async def message_count(self, uid: int) -> int:
        row = await self._fetchone("SELECT COUNT(*) FROM messages WHERE user_id=?", (uid,))
        return int(row[0]) if row else 0

    # ── semantic memory (RAG embeddings) ────────────────────────────────────────

    async def has_embedding(self, uid: int, text: str) -> bool:
        row = await self._fetchone(
            "SELECT 1 FROM embeddings WHERE user_id=? AND text=? LIMIT 1", (uid, text))
        return row is not None

    async def add_embedding(self, uid: int, kind: str, text: str, vec: list):
        await self._exec(
            "INSERT INTO embeddings(user_id, kind, text, vec, created_at) VALUES(?,?,?,?,?)",
            (uid, kind, text, json.dumps(vec), datetime.now().isoformat()),
        )

    async def all_embeddings(self, uid: int) -> list:
        rows = await self._fetchall(
            "SELECT kind, text, vec FROM embeddings WHERE user_id=?", (uid,))
        out = []
        for kind, text, vec in rows:
            try:
                out.append({"kind": kind, "text": text, "vec": json.loads(vec)})
            except Exception as exc:
                logger.warning("Подавлено исключение: %s", exc, exc_info=True)
                continue
        return out

    async def embedding_count(self, uid: int) -> int:
        row = await self._fetchone("SELECT COUNT(*) FROM embeddings WHERE user_id=?", (uid,))
        return int(row[0]) if row else 0

    async def unembedded_texts(self, uid: int, limit: int = 400) -> list:
        """User messages + facts not yet embedded (for backfill). Newest first."""
        rows = await self._fetchall(
            "SELECT text FROM ("
            "  SELECT id, text FROM messages WHERE user_id=? AND role='user' "
            "  UNION ALL SELECT id, fact AS text FROM facts WHERE user_id=?"
            ") q WHERE text NOT IN (SELECT text FROM embeddings WHERE user_id=?) "
            "ORDER BY id DESC LIMIT ?",
            (uid, uid, uid, limit),
        )
        return [r[0] for r in rows]

    # ── daily journal (life-log) ─────────────────────────────────────────────────

    async def add_journal(self, uid: int, day: str, text: str):
        text = (text or "").strip()
        if not text:
            return
        # one entry per day — replace if it already exists
        await self._exec("DELETE FROM journal WHERE user_id=? AND day=?", (uid, day))
        await self._exec(
            "INSERT INTO journal(user_id, day, text, created_at) VALUES(?,?,?,?)",
            (uid, day, text, datetime.now().isoformat()),
        )

    async def list_journal(self, uid: int, limit: int = 14) -> list:
        rows = await self._fetchall(
            "SELECT day, text FROM journal WHERE user_id=? ORDER BY day DESC LIMIT ?",
            (uid, limit),
        )
        return [{"day": r[0], "text": r[1]} for r in rows]

    async def stats(self, uid: int) -> dict:
        """Counts across every per-user table + profile fields, for /memstats."""
        await self.ensure_loaded(uid)
        counts = {}
        for tbl in USER_TABLES:
            if tbl == "profile":
                continue
            row = await self._fetchone(f"SELECT COUNT(*) FROM {tbl} WHERE user_id=?", (uid,))
            counts[tbl] = int(row[0]) if row else 0
        profile = await self.get_profile(uid)
        filled = [k for k in _PROFILE_FIELDS if (profile.get(k) or "").strip()]
        return {
            "backend": _BACKEND_LABELS[self._backend],
            "degraded": self.degraded,
            "degraded_reason": self.degraded_reason,
            "counts": counts,
            "facts_total": counts.get("facts", 0),
            "facts_in_context": len(_facts_for_context(self._cache[uid]["facts"])),
            "profile_filled": filled,
        }

    async def observe(self, uid: int, gemini, user_text: str, reply_text: str = ""):
        """Background learning: extract durable facts from an exchange and store
        them. Safe to fire-and-forget (asyncio.create_task)."""
        if not worth_learning(user_text):
            return                       # «ок»/«спасибо» — не тратим вызов модели
        try:
            facts = await gemini.extract_facts(user_text, reply_text)
            from telegram_bot import memory_rag
            for f in facts:
                added = await self.add_fact(uid, f)
                if added:
                    logger.info(f"Learned about {uid}: {f}")
                    await memory_rag.index(self, gemini, uid, "fact", f)
        except Exception as e:
            logger.debug(f"observe: {e}")


_BACKEND_LABELS = {"pg": "Postgres", "sqlite": "SQLite", "off": "нет памяти"}


def _first_line(exc: Exception) -> str:
    """Short, log-friendly reason (asyncpg tracebacks are multi-line novels)."""
    text = str(exc).strip()
    return text.splitlines()[0] if text else exc.__class__.__name__


def _pg_pool_kwargs(url: str) -> dict:
    """Transaction-mode poolers (Supabase :6543, PgBouncer) reuse server-side
    sessions, so asyncpg must not cache prepared statements."""
    if "pooler" in url or ":6543/" in url or "pgbouncer=true" in url:
        return {"statement_cache_size": 0}
    return {}


def _streak(days: set, today: str) -> int:
    """Count consecutive checked days ending today (or yesterday if today not yet
    checked, so the streak survives until a full day is actually missed)."""
    from datetime import date, timedelta
    try:
        cur = date.fromisoformat(today)
    except Exception:
        return 0
    if today not in days:
        cur = cur - timedelta(days=1)
    n = 0
    while cur.isoformat() in days:
        n += 1
        cur -= timedelta(days=1)
    return n


def _sort_tasks(items: list) -> list:
    """Dated tasks first (earliest due), then undated todos. Stable by id."""
    def key(t):
        due = t.get("due")
        return (0, due) if due else (1, "")
    return sorted(items, key=key)


def _pg(sql: str) -> str:
    """Convert '?' placeholders to Postgres '$1, $2, ...'."""
    out, n = [], 0
    for ch in sql:
        if ch == "?":
            n += 1
            out.append(f"${n}")
        else:
            out.append(ch)
    return "".join(out)


_PROFILE_FIELDS = ("name", "about", "goals", "preferences", "mode")

_SCHEMA_SQLITE = """
CREATE TABLE IF NOT EXISTS profile (
    user_id     INTEGER PRIMARY KEY,
    name        TEXT DEFAULT '',
    about       TEXT DEFAULT '',
    goals       TEXT DEFAULT '',
    preferences TEXT DEFAULT '',
    mode        TEXT DEFAULT '',
    updated_at  TEXT
);
CREATE TABLE IF NOT EXISTS facts (
    id      INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    fact    TEXT NOT NULL,
    ts      TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS tasks (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id    INTEGER NOT NULL,
    title      TEXT NOT NULL,
    due        TEXT,
    done       INTEGER DEFAULT 0,
    created_at TEXT
);
CREATE TABLE IF NOT EXISTS meta (
    user_id INTEGER NOT NULL,
    key     TEXT NOT NULL,
    value   TEXT,
    PRIMARY KEY (user_id, key)
);
CREATE TABLE IF NOT EXISTS habits (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id    INTEGER NOT NULL,
    title      TEXT NOT NULL,
    created_at TEXT
);
CREATE TABLE IF NOT EXISTS habit_checks (
    habit_id INTEGER NOT NULL,
    day      TEXT NOT NULL,
    PRIMARY KEY (habit_id, day)
);
CREATE TABLE IF NOT EXISTS reminders (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id    INTEGER NOT NULL,
    text       TEXT NOT NULL,
    due        TEXT NOT NULL,
    sent       INTEGER DEFAULT 0,
    created_at TEXT
);
CREATE TABLE IF NOT EXISTS contacts (
    user_id    INTEGER NOT NULL,
    alias      TEXT NOT NULL,
    target     TEXT NOT NULL,
    note       TEXT DEFAULT '',
    created_at TEXT,
    PRIMARY KEY (user_id, alias)
);
CREATE TABLE IF NOT EXISTS outbox (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id    INTEGER NOT NULL,
    target     TEXT NOT NULL,
    alias      TEXT NOT NULL,
    message    TEXT NOT NULL,
    as_voice   INTEGER DEFAULT 0,
    created_at TEXT
);
CREATE TABLE IF NOT EXISTS notes (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id    INTEGER NOT NULL,
    text       TEXT NOT NULL,
    created_at TEXT
);
CREATE TABLE IF NOT EXISTS schedule (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id    INTEGER NOT NULL,
    weekday    INTEGER NOT NULL,
    time       TEXT,
    subject    TEXT NOT NULL,
    location   TEXT,
    created_at TEXT
);
CREATE TABLE IF NOT EXISTS projects (
    user_id    INTEGER NOT NULL,
    name       TEXT NOT NULL,
    status     TEXT,
    updated_at TEXT,
    PRIMARY KEY (user_id, name)
);
CREATE TABLE IF NOT EXISTS messages (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id    INTEGER NOT NULL,
    role       TEXT NOT NULL,
    text       TEXT NOT NULL,
    created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS embeddings (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id    INTEGER NOT NULL,
    kind       TEXT NOT NULL,
    text       TEXT NOT NULL,
    vec        TEXT NOT NULL,
    created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS journal (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id    INTEGER NOT NULL,
    day        TEXT NOT NULL,
    text       TEXT NOT NULL,
    created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS mood (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id    INTEGER NOT NULL,
    day        TEXT NOT NULL,
    score      INTEGER,
    note       TEXT,
    created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS expenses (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id    INTEGER NOT NULL,
    amount     REAL NOT NULL,
    note       TEXT,
    day        TEXT NOT NULL,
    created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_facts_user ON facts(user_id);
CREATE INDEX IF NOT EXISTS idx_tasks_user ON tasks(user_id);
CREATE INDEX IF NOT EXISTS idx_habits_user ON habits(user_id);
CREATE INDEX IF NOT EXISTS idx_reminders_sent ON reminders(sent);
CREATE INDEX IF NOT EXISTS idx_messages_user ON messages(user_id);
"""

_SCHEMA_PG = """
CREATE TABLE IF NOT EXISTS profile (
    user_id     BIGINT PRIMARY KEY,
    name        TEXT DEFAULT '',
    about       TEXT DEFAULT '',
    goals       TEXT DEFAULT '',
    preferences TEXT DEFAULT '',
    mode        TEXT DEFAULT '',
    updated_at  TEXT
);
CREATE TABLE IF NOT EXISTS facts (
    id      BIGSERIAL PRIMARY KEY,
    user_id BIGINT NOT NULL,
    fact    TEXT NOT NULL,
    ts      TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS tasks (
    id         BIGSERIAL PRIMARY KEY,
    user_id    BIGINT NOT NULL,
    title      TEXT NOT NULL,
    due        TEXT,
    done       INTEGER DEFAULT 0,
    created_at TEXT
);
CREATE TABLE IF NOT EXISTS meta (
    user_id BIGINT NOT NULL,
    key     TEXT NOT NULL,
    value   TEXT,
    PRIMARY KEY (user_id, key)
);
CREATE TABLE IF NOT EXISTS habits (
    id         BIGSERIAL PRIMARY KEY,
    user_id    BIGINT NOT NULL,
    title      TEXT NOT NULL,
    created_at TEXT
);
CREATE TABLE IF NOT EXISTS habit_checks (
    habit_id BIGINT NOT NULL,
    day      TEXT NOT NULL,
    PRIMARY KEY (habit_id, day)
);
CREATE TABLE IF NOT EXISTS reminders (
    id         BIGSERIAL PRIMARY KEY,
    user_id    BIGINT NOT NULL,
    text       TEXT NOT NULL,
    due        TEXT NOT NULL,
    sent       INTEGER DEFAULT 0,
    created_at TEXT
);
CREATE TABLE IF NOT EXISTS contacts (
    user_id    BIGINT NOT NULL,
    alias      TEXT NOT NULL,
    target     TEXT NOT NULL,
    note       TEXT DEFAULT '',
    created_at TEXT,
    PRIMARY KEY (user_id, alias)
);
CREATE TABLE IF NOT EXISTS outbox (
    id         BIGSERIAL PRIMARY KEY,
    user_id    BIGINT NOT NULL,
    target     TEXT NOT NULL,
    alias      TEXT NOT NULL,
    message    TEXT NOT NULL,
    as_voice   INTEGER DEFAULT 0,
    created_at TEXT
);
CREATE TABLE IF NOT EXISTS notes (
    id         BIGSERIAL PRIMARY KEY,
    user_id    BIGINT NOT NULL,
    text       TEXT NOT NULL,
    created_at TEXT
);
CREATE TABLE IF NOT EXISTS schedule (
    id         BIGSERIAL PRIMARY KEY,
    user_id    BIGINT NOT NULL,
    weekday    INTEGER NOT NULL,
    time       TEXT,
    subject    TEXT NOT NULL,
    location   TEXT,
    created_at TEXT
);
CREATE TABLE IF NOT EXISTS projects (
    user_id    BIGINT NOT NULL,
    name       TEXT NOT NULL,
    status     TEXT,
    updated_at TEXT,
    PRIMARY KEY (user_id, name)
);
CREATE TABLE IF NOT EXISTS messages (
    id         BIGSERIAL PRIMARY KEY,
    user_id    BIGINT NOT NULL,
    role       TEXT NOT NULL,
    text       TEXT NOT NULL,
    created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS embeddings (
    id         BIGSERIAL PRIMARY KEY,
    user_id    BIGINT NOT NULL,
    kind       TEXT NOT NULL,
    text       TEXT NOT NULL,
    vec        TEXT NOT NULL,
    created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS journal (
    id         BIGSERIAL PRIMARY KEY,
    user_id    BIGINT NOT NULL,
    day        TEXT NOT NULL,
    text       TEXT NOT NULL,
    created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS mood (
    id         BIGSERIAL PRIMARY KEY,
    user_id    BIGINT NOT NULL,
    day        TEXT NOT NULL,
    score      INTEGER,
    note       TEXT,
    created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS expenses (
    id         BIGSERIAL PRIMARY KEY,
    user_id    BIGINT NOT NULL,
    amount     DOUBLE PRECISION NOT NULL,
    note       TEXT,
    day        TEXT NOT NULL,
    created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_facts_user ON facts(user_id);
CREATE INDEX IF NOT EXISTS idx_tasks_user ON tasks(user_id);
CREATE INDEX IF NOT EXISTS idx_habits_user ON habits(user_id);
CREATE INDEX IF NOT EXISTS idx_reminders_sent ON reminders(sent);
CREATE INDEX IF NOT EXISTS idx_messages_user ON messages(user_id);
"""
